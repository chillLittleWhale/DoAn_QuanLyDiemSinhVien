package UI.searchBar;

public interface SearchOptionEvent {

    public void optionSelected(SearchOption option, int index);
}
